{
    "mybatis-log": {
        "name": "MyBatis日志",
        "tips": "将MyBatis的sql日志中的占位符替换为实际的变量值, 生成可执行SQL",
        "icon": "Ⓜ",
        "noPage": false,
        "contentScriptJs": false,
        "contentScriptCss": false,
        "updateUrl": null
    }
}